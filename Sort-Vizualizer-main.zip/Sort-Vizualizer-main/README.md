# Sort Vizualizer
 Rodrigo and I made this cools sort visualizer that includes insertion, selection, bubble, and merge sort visualizations.
